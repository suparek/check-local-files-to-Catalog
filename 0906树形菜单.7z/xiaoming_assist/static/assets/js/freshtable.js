

function freshbyWebsocket() {
            // Correctly decide between ws:// and wss://
            var ws_scheme = window.location.protocol == "https:" ? "wss" : "ws";
            var ws_path = ws_scheme + '://' + window.location.host + "/xiaoming_vm_mng/socketdata/";
            console.log("Connecting to " + ws_path);
            var socket = new ReconnectingWebSocket(ws_path);

            socket.onopen = function () {
                console.log("Connected to socket");
                // console.log("Got open websocket message " + message.data);
                socket.send(JSON.stringify("123"));
            };

            // // 传输socket数据
            socket.onmessage = function (message) {
                
                // socket.send("1223");
                // socket.send("123");

                var objectData=JSON.parse(message.data); 


                console.log("Got websocket message " + objectData[0].machine_name );

                // // $("#machine_data").empty();
                $("tr").remove();

                console.log("length___:"+objectData.length);

                for (var i = 0; i < objectData.length; i++) {
                $("#machine_data").append(
                    "<tr class='success' data-toggle='modal' data-target='#machine_message'>"+ 
                    "<td>"+ objectData[i].machine_name    + "</td>" + 
                    "<td>"+ objectData[i].state           + "</td>" + 
                    "<td>"+ objectData[i].current_user    + "</td>" + 
                    "<td>"+ objectData[i].current_user_ip + "</td>" + 
                    "<td>"+ objectData[i].start_use_time  + "</td>" +
                    "<td>"+ objectData[i].space_left      + "</td>" +
                    "<td>"+ objectData[i].connect_address + "</td>" + 
                    "</tr>");
                }

                console.log("socket data write success");
               
            };

            // Helpful debugging
            
            
            socket.onclose = function () {
                console.log("Disconnected from socket");
            }      

}