from django.contrib import admin

# Register your models here.
from .models import Virtual_machine

admin.site.register(Virtual_machine)