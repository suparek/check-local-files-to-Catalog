# -*- coding:utf-8 -*-
from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.vm_connect,name='move'),
    url(r'^machine/$',views.virtual_machine, name='virtual_machine'),#接收list post消息
    url(r'^modaluse/$',views.machine_modal, name='machine_modal')#接收info post消息
]