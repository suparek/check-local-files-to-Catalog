# -*- coding:utf-8 -*-
# Create your views here.
from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.utils import timezone
from django.views import generic

import json

from .models import Virtual_machine



def vm_connect(request):

    return render(request, "vm_connect.html")





def virtual_machine(request):

    list_vm=[]

    for machine_data in Virtual_machine.objects.all():
        data = {
            "machine_name":machine_data.Machine_name,   
            "state":machine_data.State,          
            "current_user":machine_data.Current_user, 
            "current_user_ip":machine_data.Current_user_ip,  
            "start_use_time":machine_data.Start_use_time, 
            "space_left":machine_data.Space_left,     
            "connect_address":machine_data.Connect_address,
        }
        list_vm.append(data)

    list_vm = json.dumps(list_vm)
    response = HttpResponse(list_vm)
    # response['Access-Control-Allow-Origin']='*'
    # print "1111"
    return response


def machine_modal(request):
    # if request.method == 'POST':
    #    req = json.loads(request.body)
    #    print req
    # else:
    #    print 'abc'    
    list_vm_info=[]
    
    req = request.POST.get('param',1) 
    print req

    data = Virtual_machine.objects.get(Machine_name= req)
    
    data1 = {
            "machine_name":data.Machine_name,   
            "state":data.State,          
            "current_user":data.Current_user, 
            "current_user_ip":data.Current_user_ip,  
            "start_use_time":data.Start_use_time, 
            "space_left":data.Space_left,     
            "connect_address":data.Connect_address,
    }

    # print data1
    list_vm_info.append(data1)
    list_vm_info = json.dumps(list_vm_info)
    response = HttpResponse(list_vm_info,content_type="application/json")
    # response['Access-Control-Allow-Origin']='*'
    return response                      
