import json
from channels import Group
from channels.auth import channel_session_user_from_http, channel_session_user

from .models import Virtual_machine



def ws_connect(message):
    print "connecting"
    machine = Virtual_machine.objects.all()
    
    return Group("machine").add(message.reply_channel)
    
    
    print "connected"


def ws_receive(message):
    print "message connected"  
    # for machine_data in Virtual_machine.objects.all():
    #     data = {
    #         "machine_name":machine_data.Machine_name,   
    #         "state":machine_data.State,          
    #         "current_user":machine_data.Current_user, 
    #         "current_user_ip":machine_data.Current_user_ip,  
    #         "start_use_time":machine_data.Start_use_time, 
    #         "space_left":machine_data.Space_left,     
    #         "connect_address":machine_data.Connect_address,
    #     }

    # data = json.dumps(data)
    # print str(data)
    print message.content['path']
    print message.content['reply_channel']

    # machine = Virtual_machine.objects.all();
    
    # message.reply_channel.send({
    #         # WebSockets send either a text or binary payload each frame.
    #         # We do JSON over the text portion.
    #         "text": json.dumps(data),
    #         "close": False,
    # })

    # return Group(machine.group_name).add(message.reply_channel)
    # message.reply_channel.send(data)
    print"sendok"

def ws_disconnect(message):
	print "disconected"