# -*- coding:utf-8 -*-

from __future__ import unicode_literals
import json
from django.db import models
from django.utils.six import python_2_unicode_compatible
from channels import Group

# Create your models here.

@python_2_unicode_compatible
class Virtual_machine(models.Model):
    Machine_name    = models.CharField(max_length=200,null=True)#虚拟机名字
    State           = models.CharField(max_length=200,null=True)#虚拟机状态  空闲  预约  已经使用  未开机
    Current_user    = models.CharField(max_length=200,null=True,default=None)#虚拟机当前用户
    Current_user_ip = models.CharField(max_length=200,null=True,default=None)#虚拟机当前用户IP
    Start_use_time  = models.IntegerField(default=None,null=True)#虚拟机当前用户开始使用时间
    Space_left      = models.IntegerField(default=0,null=True)#虚拟机剩余空间
    Connect_address = models.CharField(max_length=200,null=True)#虚拟机连接地址

    class Meta:
        verbose_name='虚拟机信息'
        verbose_name_plural='虚拟机信息'

    def __str__(self):
        return self.Machine_name

    def group_name(self):
        """
        Returns the Channels Group name to use for sending notifications.
        """
        return "machine-%s" % self.id

    def send_notification(self):
        
        
        # notification = {
        #     # "machine_name":     self.Machine_name    
        #     "state":            self.State          
        #     # "current_user":     self.Current_user   
        #     # "current_user_ip":  self.Current_user_ip
        #     # "start_use_time":   self.Start_use_time 
        #     # "space_left":       self.Space_left     
        #     # "connect_address":  self.Connect_address
        # }

        list_vm=[]

        for machine_data in Virtual_machine.objects.all():
            data = {
                "machine_name":machine_data.Machine_name,   
                "state":machine_data.State,          
                "current_user":machine_data.Current_user, 
                "current_user_ip":machine_data.Current_user_ip,  
                "start_use_time":machine_data.Start_use_time, 
                "space_left":machine_data.Space_left,     
                "connect_address":machine_data.Connect_address,
            }
            list_vm.append(data)
    
        
       
        Group('machine').send({
            # WebSocket text frame, with JSON content
            "text": json.dumps(list_vm),
        })

    def save(self, *args, **kwargs):
        """
        Hooking send_notification into the save of the object as I'm not
        the biggest fan of signals.
        """
        result = super(Virtual_machine, self).save(*args, **kwargs)
        self.send_notification()
        return result