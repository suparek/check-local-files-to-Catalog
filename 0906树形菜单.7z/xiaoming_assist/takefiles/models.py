# -*- coding:utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class File_message(models.Model):

    Files_name = models.CharField(max_length=200)
    Files_route = models.CharField(max_length=200)
    Files_maketime = models.IntegerField(default=0)
    Files_modifytime = models.IntegerField(default=0)
    Files_space = models.IntegerField(default=0)

    class Meta:
        verbose_name='文件信息'
        verbose_name_plural='文件信息'

    def __str__(self):
        return self.Files_name