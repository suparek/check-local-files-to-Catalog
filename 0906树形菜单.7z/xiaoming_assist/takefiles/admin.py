from django.contrib import admin
from .models import File_message

# Register your models here.
admin.site.register(File_message)