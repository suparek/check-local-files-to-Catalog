# -*- coding:utf-8 -*-
from django.shortcuts import render
import os
import json
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.utils import timezone
from django.views import generic
from .models import File_message

# Create your views here.

def getfile_message(request):

    list_vm=[]

    for machine_data in File_message.objects.all():
        data = {
            "name":machine_data.Files_name,   
            "route":machine_data.Files_route,          
            "maketime":machine_data.Files_maketime, 
            "modifytime":machine_data.Files_modifytime,  
            "space":machine_data.Files_space, 
        }
        list_vm.append(data)

    list_vm = json.dumps(list_vm)
    return render(request, "test.html", {"filelist": list_vm})

    # response = HttpResponse(list_vm)
    # response['Access-Control-Allow-Origin']='*'
    # print "1111"
    # return response