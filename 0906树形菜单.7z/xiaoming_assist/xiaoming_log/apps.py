from __future__ import unicode_literals

from django.apps import AppConfig


class XiaomingLogConfig(AppConfig):
    name = 'xiaoming_log'
