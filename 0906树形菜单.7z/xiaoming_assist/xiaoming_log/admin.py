# -*- coding:utf-8 -*-
import sys  
reload(sys)  
sys.setdefaultencoding('utf8')
from django.contrib import admin
from .models import ServerLog,WebcyassistStatisticsAccessLog,WebcyassistantAccessLog,WebmainAccessLog,WebvncAccessLog


admin.site.register(ServerLog)
admin.site.register(WebcyassistStatisticsAccessLog)
admin.site.register(WebcyassistantAccessLog)
admin.site.register(WebmainAccessLog)
admin.site.register(WebvncAccessLog)