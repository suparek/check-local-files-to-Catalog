# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models


class ServerLog(models.Model):
    id = models.IntegerField(primary_key=True, blank=True)
    cy_state = models.CharField(max_length=100, blank=True, null=True)
    cy_time = models.CharField(max_length=100, blank=True, null=True)
    cy_hostname = models.CharField(max_length=100, blank=True, null=True)
    cy_localip = models.CharField(db_column='cy_localIP', max_length=100, blank=True, null=True)  # Field name made lowercase.
    cy_machineip = models.CharField(db_column='cy_MachineIP', max_length=100, blank=True, null=True)  # Field name made lowercase.
    cy_workpath = models.CharField(db_column='cy_Workpath', max_length=100, blank=True, null=True)  # Field name made lowercase.
    cy_edition = models.CharField(db_column='cy_Edition', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'server_log'


class WebcyassistStatisticsAccessLog(models.Model):
    id = models.IntegerField(primary_key=True, blank=True)
    username = models.CharField(max_length=100, blank=True, null=True)
    client_ip = models.CharField(max_length=100, blank=True, null=True)
    time = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'webcyassist_statistics_access_log'


class WebcyassistantAccessLog(models.Model):
    id = models.IntegerField(primary_key=True, blank=True)
    username = models.CharField(max_length=100, blank=True, null=True)
    client_ip = models.CharField(max_length=100, blank=True, null=True)
    time = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'webcyassistant_access_log'


class WebmainAccessLog(models.Model):
    id = models.IntegerField(primary_key=True, blank=True)
    username = models.CharField(max_length=100, blank=True, null=True)
    client_ip = models.CharField(max_length=100, blank=True, null=True)
    time = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'webmain_access_log'


class WebvncAccessLog(models.Model):
    id = models.IntegerField(primary_key=True, blank=True)
    username = models.CharField(max_length=100, blank=True, null=True)
    client_ip = models.CharField(max_length=100, blank=True, null=True)
    time = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'webvnc_access_log'
